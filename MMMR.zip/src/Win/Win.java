package Win;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;

import static java.lang.System.*;

public class Win {
    public static void setup1(String pairingFile,String publicFile) {

        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void setup(String pairingFile,  String publicFile,String mskFile,String KGC) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        storePropToFile(mskProp, mskFile);
        //设置主公钥
        long sta = System.nanoTime();
        Element P_pub = P.powZn(s).getImmutable();
        long end = System.nanoTime();
        // out.println(end-sta);
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);
    }


    //Registration阶段
    public static void Registration(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {

        //获得主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);

        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //生成私钥
        Element x_i=bp.getZr().newRandomElement().getImmutable();
        Element X_i=P.powZn(x_i).getImmutable();
        Element sk_i=bp.getZr().newRandomElement().getImmutable();
        Element P_i=P.powZn(sk_i).getImmutable();
        Element P_i1=P_pub.powZn(sk_i).getImmutable();
        Element CP_i=P_i.add(X_i).getImmutable();
        byte[] bh1_i=sha1(ID_i+P_i+CP_i);
        Element h1_i=bp.getZr().newElementFromHash(bh1_i,0,bh1_i.length).getImmutable();
        Element d_i = x_i.add(s.mul(h1_i)).getImmutable();

        Element P_i2=P_i.add(X_i).getImmutable();
        byte[] bh2_i=sha1(ID_i+P_i+P_i2);
        Element h2_i=bp.getZr().newElementFromHash(bh2_i,0,bh2_i.length).getImmutable();
        Element P_i3=P_i2.div(h2_i).getImmutable();


        pkp.setProperty("ID_"+ID_i, ID_i);
        pkp.setProperty("P_i_"+ID_i, P_i.toString());
        pkp.setProperty("P'_i"+ID_i, P_i2.toString());
        pkp.setProperty("P''_i"+ID_i, P_i3.toString());
        skp.setProperty("X_"+ID_i,Base64.getEncoder().encodeToString(X_i.toBytes()));
        skp.setProperty("d_"+ID_i,Base64.getEncoder().encodeToString(d_i.toBytes()));
        skp.setProperty("sk_"+ID_i,Base64.getEncoder().encodeToString(sk_i.toBytes()));
        pkp.setProperty("h_"+ID_i, h2_i.toString());

        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);

    }

    public static void Authentication1(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String KGC,String ID_u,String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties mskp=loadPropFromFile(mskFile);
        Properties pkp=loadPropFromFile(pkFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        String h_ustr=pkp.getProperty("h_"+ID_u);
        Element h_u=bp.getZr().newElementFromBytes(h_ustr.getBytes()).getImmutable();
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Properties skp=loadPropFromFile(skFile);
        String d_ustr=skp.getProperty("d_"+ID_u);
        String X_ustr=skp.getProperty("X_"+ID_u);
        Element X_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(X_ustr)).getImmutable();
        Element d_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_ustr)).getImmutable();
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
        Element r=bp.getZr().newRandomElement().getImmutable();
        Element t=bp.getZr().newRandomElement().getImmutable();
        Element L=bp.getZr().newRandomElement().getImmutable();
        Element M=bp.getZr().newRandomElement().getImmutable();
        Element sigma=bp.getZr().newRandomElement().getImmutable();
        Element Y = r.powZn(P).getImmutable();
        byte[] bm=sha1(M.toString()+sigma+L+t+Y);
        Element m = bp.getZr().newElementFromHash(bm,0,bm.length).getImmutable();
        Element a = d_u.div(h_u).add(s).add(r).getImmutable();
        Element Z = m.powZn(P).getImmutable();
        Element[] h = new Element[n],U = new Element[n];
        for (int i = 0; i < n;i++)
        {
            String P_jstr=pkp.getProperty("P_i_"+ID[i]);
            String P1_jstr=pkp.getProperty("P'_i"+ID[i]);
            String P2_jstr=pkp.getProperty("P''_i"+ID[i]);
            Element P2_j = bp.getZr().newElementFromBytes(P2_jstr.getBytes()).getImmutable();
            byte[] bh_j=sha1(ID[i]+P_jstr+P1_jstr);
            h[i] = bp.getZr().newElementFromHash(bh_j,0,bh_j.length).getImmutable();
            U[i] = m.mul(h[i].mul(P.powZn(s).add(P2_j)));

        }
        byte[] bH2=sha1(Z.toString());
        byte[] bsigma=sigma.toBytes();
        int N = Math.max(bH2.length, bsigma.length);
        int max = Math.min(bH2.length, bsigma.length);
        byte[] bV=new byte[max];
        for (int j=0;j<max;j++)
            bV[j]= (byte) (bH2[j]^bsigma[j]);
        Element V = bp.getZr().newElementFromHash(bV,0,bV.length).getImmutable();
        byte[] bK=sha1(sigma.toString());
        Element K = bp.getZr().newElementFromHash(bK,0,bK.length).getImmutable();
        Properties authp=new Properties();
        authp.setProperty("a",String.valueOf(a));
        for (int i = 0; i < n; i++)
        {
            authp.setProperty("U_"+ID[i],String.valueOf(U[i]));
            authp.setProperty("h_"+ID[i],String.valueOf(h[i]));
        }
        authp.setProperty("t",Base64.getEncoder().encodeToString(t.toBytes()));
        authp.setProperty("Y",String.valueOf(Y));
        authp.setProperty("K",String.valueOf(K));
        authp.setProperty("V",String.valueOf(V));
        authp.setProperty("L",String.valueOf(L));
        authp.setProperty("t",String.valueOf(t));
        authp.setProperty("M",String.valueOf(M));
        storePropToFile(authp,authFile);
    }

    public static void Verify1(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String veriFile,String KGC,String ID_u,String ID_i) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties mskp=loadPropFromFile(mskFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        Properties authp=loadPropFromFile(authFile);
        String U_istr = authp.getProperty("U_"+ID_i);
        String d_istr = skp.getProperty("d_"+ID_i);
        String sk_istr = skp.getProperty("sk_"+ID_i);
        String V_str = authp.getProperty("V");
        String M_str = authp.getProperty("M");
        String L_str = authp.getProperty("L");
        String t_str = authp.getProperty("t");
        String Y_str = authp.getProperty("Y");
        String a_str = authp.getProperty("a");
        String h_ustr = pkp.getProperty("h_"+ID_u);
        String h_istr = authp.getProperty("h_"+ID_i);
        Element h_u=bp.getZr().newElementFromBytes(h_ustr.getBytes()).getImmutable();
        Element h_i=bp.getG1().newElementFromBytes(h_istr.getBytes()).getImmutable();
        Element L = bp.getZr().newElementFromBytes(L_str.getBytes()).getImmutable();
        Element a = bp.getZr().newElementFromBytes(a_str.getBytes()).getImmutable();
        Element M = bp.getZr().newElementFromBytes(M_str.getBytes()).getImmutable();
        Element V = bp.getZr().newElementFromBytes(V_str.getBytes()).getImmutable();
        Element Y = bp.getZr().newElementFromBytes(Y_str.getBytes()).getImmutable();
        Element U_i=bp.getZr().newElementFromBytes(U_istr.getBytes()).getImmutable();

        Element t=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(t_str)).getImmutable();
        Element d_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(d_istr)).getImmutable();
        Element sk_i=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sk_istr)).getImmutable();
        Element Z1 = U_i.div(d_i.add(sk_i)).getImmutable();
        byte[] bH_2 = sha1(Z1.toString());
        byte[] bV = V.toBytes();
        int N = Math.max(bH_2.length, bV.length);
        int max = Math.min(bH_2.length, bV.length);
        byte[] bsigma=new byte[max];
        for (int j=0;j<max;j++)
            bsigma[j]= (byte) (bH_2[j]^bV[j]);
        Element sigma = bp.getZr().newElementFromHash(bsigma,0,bsigma.length).getImmutable();
        byte[] bH_4 = sha1(sigma.toString());
        Element K = bp.getZr().newElementFromHash(bH_4,0,bH_4.length).getImmutable();
        byte[] bH_3 = sha1(M.toString()+sigma+L+t+Y);
        Element m = bp.getZr().newElementFromHash(bH_3,0,bH_3.length).getImmutable();
        String P_ustr=pkp.getProperty("P_i_"+ID_u);
        String P1_ustr=pkp.getProperty("P'_i"+ID_u);
        String P2_ustr=pkp.getProperty("P''_i"+ID_u);
        String P2_istr=pkp.getProperty("P''_i"+ID_i);
        Element P_u=bp.getZr().newElementFromBytes(P_ustr.getBytes()).getImmutable();
        Element P2_i=bp.getZr().newElementFromBytes(P2_istr.getBytes()).getImmutable();
        Double c = 1.0;
        Element c1 = bp.getZr().newElementFromBytes(String.valueOf(c).getBytes()).getImmutable();
        Element P2_u=bp.getZr().newElementFromBytes(P2_ustr.getBytes()).getImmutable();
        Element e = P.powZn(a).sub(P_u.mul(m.sub(c1.div(h_u))).add(P2_u.add(P.powZn(s)))).getImmutable();
        if (Y.isEqual(e))
        {
//            out.println("receive");
        }
        else {
//            out.println("reject");
        }
        if (U_i.isEqual(m.powZn(h_i.powZn(P.powZn(s).add(P2_i)))))
        {
//            out.println("验证成功");
        }
        else {
//            out.println("验证失败");
        }
    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Win/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String authenticationFileName=dir+"auth.properties";
        String verifyFileName=dir+"Veri.properties";

        int n = 50;
        String KGC="KGC";
        String ID_u="User";
        String[] ID = new String[n];
        for (int i=0;i<n;i++){
//            long sta = System.currentTimeMillis();

//            long end = System.currentTimeMillis();
//            out.println(end-sta);
            ID[i] = getRandomString(10);
        }
        setup1(pairingParametersFileName,publicKeyFileName);
        setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
        Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID_u);
        for(int j = 0;j < n; j++)
            Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID[j]);
        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();

            Authentication1(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,KGC,ID_u,ID,n);
//            long start = System.currentTimeMillis();
            long end = System.currentTimeMillis();


            for (int j = 0; j < n;j++)
                Verify1(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID[j]);
//            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }





        /*long start1 = System.currentTimeMillis();

            long end1= System.currentTimeMillis();
            System.out.println(end1 - start1);


        */


    }
    public static String getRandomString(int length){

        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        Random random=new Random();

        StringBuffer sb=new StringBuffer();

        for(int i=0;i<length;i++){

            int number=random.nextInt(62);    //从62个字符中随机取其中一个

            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

        }

        return sb.toString();  //返回字符串

    }
}
