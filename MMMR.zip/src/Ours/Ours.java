package Ours;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;
import static java.lang.System.setOut;

public class Ours {

    //初始阶段


    public static void setup(String pairingFile, String publicFile,String mskFile,String KGC) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        storePropToFile(mskProp, mskFile);
        //设置主公钥
        long sta = System.nanoTime();
        Element P_pub = P.powZn(s).getImmutable();
        long end = System.nanoTime();
         // out.println(end-sta);
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);

    }

    public static void setup1(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }

    //Registration阶段
    public static void Registration(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {

        //获得主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);

        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //生成私钥
            //用户自己选择私钥
        Element x_i=bp.getZr().newRandomElement().getImmutable();
        Element X_i=P.powZn(x_i).getImmutable();

            //KGC生成部分私钥
        Element r_i=bp.getZr().newRandomElement().getImmutable();
        Element R_i=P.powZn(r_i).getImmutable();

            //生成假名
        byte[] bH0_i=sha0(ID_i+s.toString());
        byte[] bR_i=R_i.toBytes();
        int n = Math.max(bH0_i.length, bR_i.length);
        int m = Math.min(bH0_i.length, bR_i.length);
        byte[] bPID_i=new byte[n];
        for (int i=0;i<m;i++)
            bPID_i[i]= (byte) (bH0_i[i]^bR_i[i]);
        Element Pid_i=bp.getZr().newElementFromHash(bPID_i,0,bPID_i.length).getImmutable();


        //KGC
        byte[] bH1_i = sha0(ID_i + X_i.toString() + R_i.toString() + P_pub.toString());
        Element H1_i = bp.getZr().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element sH1_i =s.mul(H1_i).getImmutable();
        Element ld_i = r_i.add(sH1_i).getImmutable();

            //验证
        if (P.powZn(ld_i).isEqual(R_i.add(P.powZn(sH1_i)))){
            pkp.setProperty("Pid_"+ID_i,Pid_i.toString());
            skp.setProperty("r_"+ID_i,Base64.getEncoder().encodeToString(r_i.toBytes()));
            pkp.setProperty("R_"+ID_i,R_i.toString());
            skp.setProperty("x_"+ID_i,Base64.getEncoder().encodeToString(x_i.toBytes()));
            pkp.setProperty("X_"+ID_i,X_i.toString());
            skp.setProperty("ld_"+ID_i,Base64.getEncoder().encodeToString(ld_i.toBytes()));


        }

        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);

    }


    public static void Authentication(String pairingFile, String publicFile, String mskFile, String pkFile, String skFile, String authFile, String KGC, String ID_u, String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
            //获取假名
        Properties pkp=loadPropFromFile(pkFile);
        String Pid_ustr=pkp.getProperty("Pid_"+ID_u);
        String[] Pidi_str = new String[n];
        Element[] Pid_i = new Element[n];
        for(int i = 0; i < n; i++)
        {
            Pidi_str[i] = pkp.getProperty("Pid_"+ID[i]);
            Pid_i[i] = bp.getZr().newElementFromBytes(Pidi_str[i].getBytes()).getImmutable();
        }
            //获得私钥
        Properties skp=loadPropFromFile(skFile);
        String x_ustr=skp.getProperty("x_"+ID_u);
        String ld_ustr=skp.getProperty("ld_"+ID_u);
        String[] x_istr = new String[n], ld_istr = new String[n],r_istr= new String[n],R_istr= new String[n],X_istr= new String[n];
        for (int i = 0; i < n; i++)
        {
            x_istr[i]=skp.getProperty("x_"+ID[i]);
            ld_istr[i]=skp.getProperty("ld_"+ID[i]);
            r_istr[i]=skp.getProperty("r_"+ID[i]);
            R_istr[i]=pkp.getProperty("R_"+ID[i]);
            X_istr[i]=pkp.getProperty("X_"+ID[i]);
        }
        Element x_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_ustr)).getImmutable();
        Element ld_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(ld_ustr)).getImmutable();

        Element []x_i = new Element[n],ld = new Element[n],X = new Element[n], r = new Element[n],R = new Element[n];
        for(int i = 0; i < n; i++)
        {
            x_i[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr[i])).getImmutable();
            ld[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(ld_istr[i])).getImmutable();
            r[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(r_istr[i])).getImmutable();
            R[i] = bp.getG1().newElementFromBytes(R_istr[i].getBytes()).getImmutable();
            X[i] = bp.getG1().newElementFromBytes(X_istr[i].getBytes()).getImmutable();

        }

            //用户发送给医院部门
        Element  t = bp.getZr().newRandomElement().getImmutable();
        Element T = P.powZn(t).getImmutable();
        Element[] h1_i = new Element[n],Q = new Element[n],gm = new Element[n];
        for(int i = 0; i < n; i++){
            byte[] bh1 =sha0(Pidi_str[i] + X_istr[i] + R_istr[i] + P_pubstr);
            h1_i[i]=bp.getZr().newElementFromHash(bh1,0,bh1.length).getImmutable();
            Element e = x_u.add(ld_u.add(t)).getImmutable();
            Q[i]= X[i].add(R[i]).add(P.powZn(s.mul(h1_i[i]))).powZn(e);
            byte[] bgm_i = sha0(Q[i].toString());
            gm[i] = bp.getZr().newElementFromHash(bgm_i,0,bgm_i.length).getImmutable();
        }
        double x = new Random().nextDouble(),theta;
        double []A = new double[n];
        for(int i = 0; i < n; i++)
            A[i] = new Random().nextDouble();
        double sum1 = Math.pow(x,n), sum2 = 1;
        for(int i = 0;i < n; i++)
        {
            sum1+= A[i]*Math.pow(x,i);
            sum2*=x-Double.valueOf(gm[i].toString());
        }
        theta = sum1 - sum2;
        String sum3 = new String();
        for(int i = 0; i < n; i++)
            sum3+=String.valueOf(A[i]);
        Element sum2_1 = bp.getG1().newElementFromBytes(String.valueOf(sum2).getBytes()).getImmutable();
        Element sum1_1 = bp.getG1().newElementFromBytes(String.valueOf(sum1).getBytes()).getImmutable();
        Element theta_1 = bp.getG1().newElementFromBytes(String.valueOf(theta).getBytes()).getImmutable();
        byte[] d1 =sha0(Pid_ustr+T.toString()+String.valueOf(theta)+sum3);
        Element d2=bp.getG1().newElementFromHash(d1,0,d1.length).getImmutable();
        Element sigema = d2.powZn(t.add(x_u)).add(d2.powZn(ld_u)).add(theta_1);
        Properties authp=new Properties();
        authp.setProperty("f(x)",String.valueOf(sum1));
        authp.setProperty("T",String.valueOf(T));
        for(int i = 0; i < n; i++)
        {
            authp.setProperty("Q_"+i, String.valueOf(Q[i]));
            authp.setProperty("A_"+i, String.valueOf(A[i]));
            authp.setProperty("gm_"+i, String.valueOf(gm[i]));
        }
        authp.setProperty("d1",String.valueOf(d2));
        authp.setProperty("sigema",String.valueOf(sigema));
        authp.setProperty("sum3",String.valueOf(sum3));
        authp.setProperty("t",Base64.getEncoder().encodeToString(t.toBytes()));
        authp.setProperty("T",Base64.getEncoder().encodeToString(T.toBytes()));
        storePropToFile(authp,authFile);

    }
    public static void Verify(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String veriFile,String KGC,String ID_u,String[] ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties mskp=loadPropFromFile(mskFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();

        //获取假名
        Properties pkp=loadPropFromFile(pkFile);
        String Pid_ustr=pkp.getProperty("Pid_"+ID_u);
        Element Pid_i=bp.getZr().newElementFromBytes(Pid_ustr.getBytes()).getImmutable();

        //获得私钥
        Properties skp=loadPropFromFile(skFile);
        String[] x_istr = new String[n], ld_istr = new String[n],r_istr= new String[n],R_istr= new String[n],X_istr= new String[n];
        Element []x_i = new Element[n],ld = new Element[n],X = new Element[n], r = new Element[n],R = new Element[n];
        String r_ustr=skp.getProperty("r_"+ID_u);
        String R_ustr=pkp.getProperty("R_"+ID_u);
        String X_ustr=pkp.getProperty("X_"+ID_u);
        Element X_u = bp.getG1().newElementFromBytes(X_ustr.getBytes()).getImmutable();
        Element R_u = bp.getG1().newElementFromBytes(R_ustr.getBytes()).getImmutable();

        for(int i = 0; i < n; i++)
        {
            x_istr[i] =skp.getProperty("x_"+ID[i]);
            ld_istr[i]=skp.getProperty("ld_"+ID[i]);
            r_istr[i]=skp.getProperty("r_"+ID[i]);
            R_istr[i]=pkp.getProperty("R_"+ID[i]);
            X_istr[i]=pkp.getProperty("X_"+ID[i]);
            x_i[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr[i])).getImmutable();
            ld[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(ld_istr[i])).getImmutable();
            X[i] = bp.getG1().newElementFromBytes(X_istr[i].getBytes()).getImmutable();
            r[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(r_istr[i])).getImmutable();
            R[i] = bp.getG1().newElementFromBytes(R_istr[i].getBytes()).getImmutable();
        }
        Properties authp=loadPropFromFile(authFile);
        String Sstr=authp.getProperty("f(x)");
        String sum3=authp.getProperty("sum3");
        String Tstr=authp.getProperty("T");
        String sigemastr=authp.getProperty("sigema");
        String[] A_str = new String[n], Q_str = new String[n], gm_str = new String[n];
        Element[] A = new Element[n], Q = new Element[n], gm = new Element[n];
        for(int i = 0; i < n; i++) {
            A_str[i] = authp.getProperty("A_" + i);
            Q_str[i]=authp.getProperty("Q_"+i);
            gm_str[i]=authp.getProperty("gm_"+i);
        }
        String d1str=authp.getProperty("d1");
        String tstr=authp.getProperty("t");
        Element Sum=bp.getG1().newElementFromBytes(Sstr.getBytes()).getImmutable();
        for(int i = 0; i < n; i++)
        {
            A[i] = bp.getG1().newElementFromBytes(A_str[i].getBytes()).getImmutable();
            Q[i] = bp.getG1().newElementFromBytes(Q_str[i].getBytes()).getImmutable();
            gm[i] = bp.getG1().newElementFromBytes(gm_str[i].getBytes()).getImmutable();
        }
        Element sigema=bp.getG1().newElementFromBytes(sigemastr.getBytes()).getImmutable();
        Element d1=bp.getG1().newElementFromBytes(d1str.getBytes()).getImmutable();
        Element T=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Tstr)).getImmutable();
        Element t=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(tstr)).getImmutable();
        Properties verip=new Properties();

        //D_i验证
        byte[] bh =sha0(Pid_ustr + X_ustr + R_ustr + P_pubstr);
        Element h1 =bp.getZr().newElementFromHash(bh,0,bh.length).getImmutable();
        Element[] Q_1 = new Element[n],gm_1 = new Element[n];
        for(int i = 0; i < n; i++)
        {
            Element e = x_i[i].add(ld[i]).getImmutable();
            Q_1[i] = X_u.add(R_u.add(P.powZn(s.mul(h1)))).add(T).powZn(e);
            byte[] bgm_i = sha0(Q[i].toString());
            gm_1[i] = bp.getZr().newElementFromHash(bgm_i,0,bgm_i.length).getImmutable();
        }

        Double sum2 = 1.0;

        for(int i = 0; i < n; i++)
        {
            String str1 = gm_1[i].toString();
            sum2*=Double.valueOf(str1) - Double.valueOf(gm_str[i]);
        }
        Double theta1 = Double.valueOf(Sstr) - sum2;
        byte[] d3 =sha0(Pid_ustr+T.toString()+theta1+sum3);
        Element d4=bp.getG1().newElementFromHash(d3,0,d3.length).getImmutable();
        Element s1 = d4.mul(T.add(X_u)).add(d4.mul(R_u.add(P_pub.powZn(h1))));
        Element theta1_1 = bp.getG1().newElementFromBytes(String.valueOf(theta1).getBytes()).getImmutable();
//        if(s1.isEqual(sigema.sub(theta1_1))){
//            out.println("1");
//
//
//            out.println("2");
//            out.println("V_i验证成功");
//            }
//            else {
//                out.println(s1);
//                out.println(sigema);
//                out.println(theta1_1);
//                out.println("验证失败2");
//            }


    }



    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Ours_File/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String authenticationFileName=dir+"auth.properties";
        String verifyFileName=dir+"Veri.properties";

        int n = 40;
        String KGC="KGC";
        String ID_u="User";
        String[] ID = new String[n];
        for (int i=0;i<n;i++){
//            long sta = System.currentTimeMillis();

//            long end = System.currentTimeMillis();
//            out.println(end-sta);
            ID[i] = getRandomString(10);
        }
        setup1(pairingParametersFileName,publicKeyFileName);
        setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
        Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID_u);

        for(int j = 0;j < n; j++)
            Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID[j]);
//            long start = System.currentTimeMillis();
//            long end = System.currentTimeMillis();
//            System.out.println(end - start);
        for (int i=0;i<10;i++){
            long sta = System.currentTimeMillis();

            Authentication(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,KGC,ID_u,ID,n);
//            long end = System.currentTimeMillis();
//            long sta = System.currentTimeMillis();

            Verify(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID,n);

            long end = System.currentTimeMillis();
            out.println(end-sta);

        }
//        long start = System.currentTimeMillis();
//        Authentication(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,KGC,ID_u,ID,n);
//        Verify(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID,n);
//        long end = System.currentTimeMillis();
//        System.out.println(end - start);




        /*long start1 = System.currentTimeMillis();

            long end1= System.currentTimeMillis();
            System.out.println(end1 - start1);


        */


    }


    public static String getRandomString(int length){

            String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            Random random=new Random();

            StringBuffer sb=new StringBuffer();

            for(int i=0;i<length;i++){

                int number=random.nextInt(62);    //从62个字符中随机取其中一个

                sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

            }

            return sb.toString();  //返回字符串

    }
}
