package Li;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;

public class Li {

    public static void setup(String pairingFile, String publicFile,String mskFile,String KGC) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        storePropToFile(mskProp, mskFile);
        //设置主公钥
        long sta = System.nanoTime();
        Element P_pub = P.powZn(s).getImmutable();
        long end = System.nanoTime();
        // out.println(end-sta);
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);

    }

    public static void setup1(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void PartialKeyGeneration(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        String P_pubistr=PubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        byte[] bH_1=sha1(ID_i);
        Element QID_i = bp.getG1().newElementFromHash(bH_1,0,bH_1.length).getImmutable();
        Element SID_i = QID_i.powZn(s);
        skp.setProperty("SID_"+ID_i, Base64.getEncoder().encodeToString(SID_i.toBytes()));//element和string类型之间的转换需要通
        pkp.setProperty("QID_"+ID_i,QID_i.toString());
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
    }
    public static void Signcryption(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String KGC,String ID_u,String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Properties authp=new Properties();
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
        Element r_0=bp.getG1().newRandomElement().getImmutable();
        Element r_1=bp.getZr().newRandomElement().getImmutable();
        Element r_2=bp.getZr().newRandomElement().getImmutable();
        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        String SID_ustr=skp.getProperty("SID_"+ID_u);
        String QID_ustr=pkp.getProperty("QID_"+ID_u);
        Element[] QID=new Element[n];
        for (int i =0 ; i< n;i++)
        {
            String QIDstr = pkp.getProperty("QID_"+ID[i]);
            QID[i] = bp.getG1().newElementFromBytes(QIDstr.getBytes()).getImmutable();
        }
        Element SID_u=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(SID_ustr)).getImmutable();
        Element QID_u=bp.getG1().newElementFromBytes(QID_ustr.getBytes()).getImmutable();
        Element J = r_0.powZn(P_pub);
        Element Y = r_0.powZn(P);
        Element[] x = new Element[n];
        for (int i = 0; i < n; i++)
        {
            byte[] bH_2 = sha1(bp.pairing(SID_u,QID_u).getImmutable().toString());
            x[i] = bp.getZr().newElementFromHash(bH_2,0,bH_2.length).getImmutable();
        }
        Element[] m= new Element[n];
        Element M = bp.getZr().newOneElement();

        for (int i = 0;i < n;i++)
        {
            m[i] = bp.getZr().newRandomElement().getImmutable();
            byte[] bm = m[i].toBytes();
            byte[] bx = x[i].toBytes();
            int max = Math.max(bx.length, bm.length);
            int min = Math.min(bx.length, bm.length);
            byte[] bxm=new byte[max];
            for (int j = 0;j<max;j++ )
                bxm[j] = (byte) (bm[j]^bx[j]);
            Element M1=bp.getZr().newElementFromHash(bxm,0,bxm.length).getImmutable();
            M = M.add(M1).getImmutable();
        }
        Element[] fai = new Element[n];
        String sum = new String();
        for (int i = 0; i < n;i++)
        {
            byte[] bH_3 = sha1(bp.pairing(QID[i],J).getImmutable().toString());
            byte[] br_1 = r_1.toBytes();
            int max = Math.max(bH_3.length, br_1.length);
            byte[] bHr=new byte[max];
            for (int j = 0;j<max;j++ )
                bHr[j] = (byte) (bH_3[j]^br_1[j]);
            fai[i] = bp.getZr().newElementFromHash(bHr,0,bHr.length).getImmutable();
            sum+=fai[i].toString();
            authp.setProperty("fai_"+ID[i],fai[i].toString());
        }
        byte[] bK = sha1(r_1.toString());
        Element K = bp.getZr().newElementFromHash(bK,0,bK.length).getImmutable();
        Element C = K.add(M).getImmutable();
        Element U = r_2.powZn(P_pub).getImmutable();
        byte[] bh = sha1(C.toString()+U.toString()+sum+Y.toString());
        Element h = bp.getZr().newElementFromHash(bh,0,bh.length).getImmutable();
        Element V = SID_u.powZn(r_2.add(h)).getImmutable();

        authp.setProperty("h",h.toString());
        authp.setProperty("C",C.toString());
        authp.setProperty("Y",Y.toString());
        authp.setProperty("U",U.toString());
        authp.setProperty("V",V.toString());

        storePropToFile(authp,authFile);
    }



    public static void Verify(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String veriFile,String KGC,String ID_u,String ID_i) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties mskp=loadPropFromFile(mskFile);
        Properties pkp=loadPropFromFile(pkFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        String QID_ustr=pkp.getProperty("QID_"+ID_u);
        Element QID_u=bp.getG1().newElementFromBytes(QID_ustr.getBytes()).getImmutable();
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
        Properties authp=loadPropFromFile(authFile);
        String U_str=authp.getProperty("U");
        Element U=bp.getG1().newElementFromBytes(U_str.getBytes()).getImmutable();
        String Y_str=authp.getProperty("Y");
        Element Y=bp.getZr().newElementFromBytes(Y_str.getBytes()).getImmutable();
        String C_str=authp.getProperty("C");
        Element C=bp.getZr().newElementFromBytes(C_str.getBytes()).getImmutable();
        String V_str=authp.getProperty("V");
        Element V=bp.getG1().newElementFromBytes(V_str.getBytes()).getImmutable();



            String fai_str=authp.getProperty("fai_"+ID_i);
            Element fai=bp.getZr().newElementFromBytes(fai_str.getBytes()).getImmutable();


        byte[] bH_4=sha1(C.toString()+U.toString()+Y.toString()+V.toString());
        Element h = bp.getG1().newElementFromHash(bH_4,0,bH_4.length).getImmutable();
        if (bp.pairing(V,P).getImmutable().isEqual(bp.pairing(QID_u,U.add(h.powZn(P_pub))).getImmutable())){}
//            out.println("验证成功");
        else
            out.println("fail");

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Li/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String authenticationFileName=dir+"auth.properties";
        String verifyFileName=dir+"Veri.properties";


        int n = 50;
        String KGC="KGC";
        String ID_u="User";
        String[] ID = new String[n];
        for (int i=0;i<n;i++){
//            long sta = System.currentTimeMillis();

//            long end = System.currentTimeMillis();
//            out.println(end-sta);
            ID[i] = getRandomString(10);
        }
        setup1(pairingParametersFileName,publicKeyFileName);
        setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
        PartialKeyGeneration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID_u);

        for(int j = 0;j < n; j++)
            PartialKeyGeneration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID[j]);
//            long start = System.currentTimeMillis();
//            long end = System.currentTimeMillis();
//            System.out.println(end - start);
        for (int i=0;i<10;i++){
//            long sta = System.currentTimeMillis();

            Signcryption(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,KGC,ID_u,ID,n);
//            long end = System.currentTimeMillis();
            long sta = System.currentTimeMillis();
            for (int j = 0; j < n; j++)
                Verify(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID[j]);

            long end = System.currentTimeMillis();
            out.println(end-sta);

        }




        /*long start1 = System.currentTimeMillis();

            long end1= System.currentTimeMillis();
            System.out.println(end1 - start1);


        */


    }
    public static String getRandomString(int length){

        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        Random random=new Random();

        StringBuffer sb=new StringBuffer();

        for(int i=0;i<length;i++){

            int number=random.nextInt(62);    //从62个字符中随机取其中一个

            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

        }

        return sb.toString();  //返回字符串

    }
}
