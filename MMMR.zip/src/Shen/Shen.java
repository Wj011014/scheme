package Shen;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;

import static java.lang.System.out;

public class Shen {

    public static void setup1(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getG1().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void setup(String pairingFile,  String publicFile,String mskFile,String KGC) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P = bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        storePropToFile(mskProp, mskFile);
        //设置主公钥
        long sta = System.nanoTime();
        Element P_pub = P.powZn(s).getImmutable();
        long end = System.nanoTime();
        // out.println(end-sta);
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);

    }


    public static void Registration(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {

        //获得主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);

        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //生成私钥
        Element x_i=bp.getZr().newRandomElement().getImmutable();
        Element X_i=P.powZn(x_i).getImmutable();
        Element z_i=bp.getZr().newRandomElement().getImmutable();
        Element Y_i=P.powZn(z_i).getImmutable();

        byte[] bH1_i=sha1(ID_i+Y_i.toString()+X_i.toString());

        Element H1_i=bp.getZr().newElementFromHash(bH1_i,0,bH1_i.length).getImmutable();
        Element y_i=z_i.add(s.mul(H1_i));

        if (P.powZn(y_i).isEqual(Y_i.add(P_pub.powZn(H1_i)))){
            pkp.setProperty("X_"+ID_i,X_i.toString());
            pkp.setProperty("Y_"+ID_i,Y_i.toString());
            skp.setProperty("x_"+ID_i,Base64.getEncoder().encodeToString(x_i.toBytes()));
            skp.setProperty("y_"+ID_i,Base64.getEncoder().encodeToString(y_i.toBytes()));



        }

        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);

    }

    public static void Authentication(String pairingFile, String publicFile, String mskFile, String pkFile, String skFile, String authFile, String KGC, String ID_u, String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Properties pubProp=loadPropFromFile(publicFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
        Properties pkp=loadPropFromFile(pkFile);

        //获得私钥
        Properties skp=loadPropFromFile(skFile);
        String x_ustr=skp.getProperty("x_"+ID_u);
        String y_ustr=skp.getProperty("y_"+ID_u);
        String[] x_istr = new String[n], y_istr = new String[n],Y_istr= new String[n],X_istr= new String[n];
        for (int i = 0; i < n; i++)
        {
            x_istr[i]=skp.getProperty("x_"+ID[i]);
            y_istr[i]=skp.getProperty("y_"+ID[i]);
            X_istr[i]=pkp.getProperty("X_"+ID[i]);
            Y_istr[i]=pkp.getProperty("Y_"+ID[i]);
        }
        Element x_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_ustr)).getImmutable();
        Element y_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(y_ustr)).getImmutable();

        Element []x_i = new Element[n],y = new Element[n],X = new Element[n], Y = new Element[n];
        for(int i = 0; i < n; i++)
        {
            x_i[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr[i])).getImmutable();
            y[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(y_istr[i])).getImmutable();
            Y[i] = bp.getG1().newElementFromBytes(Y_istr[i].getBytes()).getImmutable();
            X[i] = bp.getG1().newElementFromBytes(X_istr[i].getBytes()).getImmutable();

        }

        //用户发送给医院部门
        Element d=bp.getZr().newRandomElement().getImmutable();
        Element b=bp.getZr().newRandomElement().getImmutable();
        Element m=bp.getZr().newRandomElement().getImmutable();
        Element D=P.powZn(d).getImmutable();
        Element B=P.powZn(b).getImmutable();
        Element[] T = new Element[n],h_i = new Element[n];
        for(int i = 0; i < n; i++){
            byte[] b_h = sha1(ID[i]+Y[i].toString()+X[i].toString());
            h_i[i] = bp.getG1().newElementFromHash(b_h,0,b_h.length).getImmutable();
            Element e =h_i[i].powZn(P_pub).add(Y[i].add(X[i])).powZn(x_u).getImmutable();
            byte[] bT_i =sha1(e.toString());
            T[i]=bp.getZr().newElementFromHash(bT_i,0,bT_i.length).getImmutable();

        }

        double x = new Random().nextDouble(),theta;
        double []A = new double[n];
        for(int i = 0; i < n; i++)
            A[i] = new Random().nextDouble();
        double sum1 = Math.pow(x,n), sum2 = 1;
        for(int i = 0;i < n; i++)
        {
            sum1+= A[i]*Math.pow(x,i);
            sum2*=x-Double.valueOf(T[i].toString());
        }
        theta = sum1 - sum2;
        String sum3 = new String();
        for(int i = 0; i < n; i++)
            sum3+=String.valueOf(A[i]);
        Element sum2_1 = bp.getG1().newElementFromBytes(String.valueOf(sum2).getBytes()).getImmutable();
        Element sum1_1 = bp.getG1().newElementFromBytes(String.valueOf(sum1).getBytes()).getImmutable();
        Element theta_1 = bp.getG1().newElementFromBytes(String.valueOf(theta).getBytes()).getImmutable();
        byte[] bK1 = sha1(String.valueOf(theta));
        Element K1 = bp.getG1().newElementFromHash(bK1,0,bK1.length).getImmutable();

        byte[] bR_i=m.toBytes();
        int N = Math.max(bK1.length, bR_i.length);
        int M = Math.min(bK1.length, bR_i.length);
        byte[] bC_m=new byte[n];
        for (int i=0;i<M;i++)
            bC_m[i]= (byte) (bK1[i]^bR_i[i]);
        Element C_m=bp.getZr().newElementFromHash(bC_m,0,bC_m.length).getImmutable();
        byte[] bR = sha1(ID_u+m.toString()+D.toString()+theta);
        Element R = bp.getZr().newElementFromHash(bR,0,bR.length).getImmutable();
        Element g = d.powZn(R).getImmutable();
        Element V1 = x_u.add(y_u).div(g);
        byte[] bW = sha1(ID_u+m+B.toString()+theta);
        Element W = bp.getZr().newElementFromHash(bW,0,bW.length).getImmutable();
        Element V2 = x_u.add(y_u).div(W.powZn(b));

        Properties authp=new Properties();
        authp.setProperty("R", String.valueOf(R));
        authp.setProperty("B", String.valueOf(B));
        authp.setProperty("W", String.valueOf(W));
        authp.setProperty("V2", String.valueOf(V2));
        authp.setProperty("V1", String.valueOf(V1));
        authp.setProperty("D", String.valueOf(D));
        authp.setProperty("C_m", String.valueOf(C_m));
        authp.setProperty("f(x)",String.valueOf(sum1));

        for(int i = 0; i < n; i++)
        {
            authp.setProperty("T_"+i, String.valueOf(T[i]));
            authp.setProperty("A_"+i, String.valueOf(A[i]));
        }
        authp.setProperty("sum3",sum3);
        authp.setProperty("d",Base64.getEncoder().encodeToString(d.toBytes()));
        authp.setProperty("D",Base64.getEncoder().encodeToString(D.toBytes()));
        authp.setProperty("b",Base64.getEncoder().encodeToString(d.toBytes()));
        authp.setProperty("B",Base64.getEncoder().encodeToString(D.toBytes()));

        storePropToFile(authp,authFile);

    }
    public static void Verify(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String authFile,String veriFile,String KGC,String ID_u,String[] ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties mskp=loadPropFromFile(mskFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getG1().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubstr.getBytes()).getImmutable();


        Properties pkp=loadPropFromFile(pkFile);

        //获得私钥
        Properties skp=loadPropFromFile(skFile);
        String[] x_istr = new String[n], y_istr = new String[n],Y_istr= new String[n],X_istr= new String[n];
        Element []x_i = new Element[n],y = new Element[n],X = new Element[n],Y = new Element[n];
        String y_ustr=skp.getProperty("y_"+ID_u);
        String Y_ustr=pkp.getProperty("Y_"+ID_u);
        String X_ustr=pkp.getProperty("X_"+ID_u);
        Element X_u = bp.getG1().newElementFromBytes(X_ustr.getBytes()).getImmutable();
        Element Y_u = bp.getG1().newElementFromBytes(Y_ustr.getBytes()).getImmutable();

        for(int i = 0; i < n; i++)
        {
            x_istr[i] =skp.getProperty("x_"+ID[i]);
            y_istr[i]=skp.getProperty("y_"+ID[i]);
            Y_istr[i]=pkp.getProperty("Y_"+ID[i]);
            X_istr[i]=pkp.getProperty("X_"+ID[i]);
            x_i[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(x_istr[i])).getImmutable();
            y[i]=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(y_istr[i])).getImmutable();
            X[i] = bp.getG1().newElementFromBytes(X_istr[i].getBytes()).getImmutable();
            Y[i] = bp.getG1().newElementFromBytes(Y_istr[i].getBytes()).getImmutable();
        }
        Properties authp=loadPropFromFile(authFile);
        String Sstr=authp.getProperty("f(x)");
        String sum3=authp.getProperty("sum3");
        String C_mstr = authp.getProperty("C_m");
        String V1str=authp.getProperty("V1");
        String Dstr=authp.getProperty("D");
        String Bstr=authp.getProperty("B");
        String V2str=authp.getProperty("V2");

        String[] A_str = new String[n], T_str = new String[n];
        Element[] A = new Element[n], T = new Element[n];
        for(int i = 0; i < n; i++) {
            A_str[i] = authp.getProperty("A_" + i);
            T_str[i]=authp.getProperty("T_"+i);

        }
        Element Sum=bp.getG1().newElementFromBytes(Sstr.getBytes()).getImmutable();
        Element V1 = bp.getG1().newElementFromBytes(V1str.getBytes()).getImmutable();
        for(int i = 0; i < n; i++)
        {
            A[i] = bp.getG1().newElementFromBytes(A_str[i].getBytes()).getImmutable();
            T[i] = bp.getG1().newElementFromBytes(T_str[i].getBytes()).getImmutable();
        }
        Element D=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Dstr)).getImmutable();
        Element B=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Bstr)).getImmutable();
        Element V2 = bp.getG1().newElementFromBytes(V2str.getBytes()).getImmutable();

        Properties verip=new Properties();

        //D_i验证
        Element[] T_1 = new Element[n];
        for(int i = 0; i < n; i++)
        {
            byte[] bT_1 =sha1(X_u.powZn(x_i[i].add(y[i])).toString());
            T_1[i] = bp.getZr().newElementFromHash(bT_1,0,bT_1.length).getImmutable();
        }


        Double sum2 = 1.0;

        for(int i = 0; i < n; i++)
        {
            String str1 = T_1[i].toString();
            sum2*=Double.valueOf(str1) - Double.valueOf(T_str[i]);
        }
        Double theta1 = Double.valueOf(Sstr) - sum2;
        byte[] bK1 =sha1(theta1.toString());
        Element K1=bp.getG1().newElementFromHash(bK1,0,bK1.length).getImmutable();
        byte[] bC_m=C_mstr.getBytes(StandardCharsets.UTF_8);
        int N = Math.max(bK1.length, bC_m.length);
        int M = Math.min(bK1.length, bC_m.length);
        byte[] b_m=new byte[n];
        for (int i=0;i<M;i++)
            b_m[i]= (byte) (bK1[i]^bC_m[i]);
        Element m=bp.getG1().newElementFromHash(b_m,0,b_m.length).getImmutable();
        byte[] R1_m=sha1(ID_u+m.toString()+D.toString()+theta1);
        Element R1 = bp.getG1().newElementFromHash(R1_m,0,R1_m.length).getImmutable();
        byte[] bH_1=sha1(ID_u+Y_u+X_u);
        Element H_1 = bp.getG1().newElementFromHash(bH_1,0,bH_1.length).getImmutable();

        if (R1.mul(V1.mul(D)).isEqual(X_u.add(Y_u.add(P_pub.mul(H_1)))))
        {
//            out.println("解密成功");
        }
        else {
//            out.println("解密失败");
        }
        byte[] bW=sha1(ID_u+m+X_u+Bstr+theta1);
        Element W = bp.getG1().newElementFromHash(bW,0,bW.length).getImmutable();
        Element theta1_1 = bp.getG1().newElementFromBytes(String.valueOf(theta1).getBytes()).getImmutable();

        if(W.mul(V2.mul(B)).isEqual(X_u.add(Y_u.add(P_pub.mul(H_1))))){
//            out.println("1");
//
//
//            out.println("2");
//            out.println("验证成功");
            }
            else {
//                out.println(s1);
//                out.println(sigema);
//                out.println(theta1_1);
//                out.println("验证失败2");
            }


    }

    /*
将程序变量数据存储到文件中
 */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Shen/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String authenticationFileName=dir+"auth.properties";
        String verifyFileName=dir+"Veri.properties";

        int n = 50;
        String KGC="KGC";
        String ID_u="User";
        String[] ID = new String[n];
        for (int i=0;i<n;i++){
//            long sta = System.currentTimeMillis();

//            long end = System.currentTimeMillis();
//            out.println(end-sta);
            ID[i] = getRandomString(10);
        }
        setup1(pairingParametersFileName,publicKeyFileName);
        setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
        Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID_u);

        for(int j = 0;j < n; j++)
            Registration(pairingParametersFileName,publicParameterFileName,mskFileName,publicKeyFileName,secretKeyFileName,KGC,ID[j]);
//            long start = System.currentTimeMillis();
//            long end = System.currentTimeMillis();
//            System.out.println(end - start);
        for (int i=0;i<10;i++){
//            long sta = System.currentTimeMillis();

            Authentication(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,KGC,ID_u,ID,n);
//            long end = System.currentTimeMillis();
            long sta = System.currentTimeMillis();
            Verify(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID,n);

            long end = System.currentTimeMillis();
            out.println(end-sta);

        }










    }
    public static String getRandomString(int length){

        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        Random random=new Random();

        StringBuffer sb=new StringBuffer();

        for(int i=0;i<length;i++){

            int number=random.nextInt(62);    //从62个字符中随机取其中一个

            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

        }

        return sb.toString();  //返回字符串

    }

}
