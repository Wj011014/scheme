package Yu;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import static java.lang.System.*;

public class Yu {


    public static void setup(String pairingFile, String publicFile,String mskFile,String KGC) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Properties PubProp =loadPropFromFile(publicFile);
        String Pstr=PubProp.getProperty("P");
        Element P = bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置KGC的主私钥
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        mskProp.setProperty("s_"+KGC, Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        storePropToFile(mskProp, mskFile);
        //设置主公钥
        long sta = System.nanoTime();
        Element P_pub = P.powZn(s).getImmutable();
        long end = System.nanoTime();
        // out.println(end-sta);
        PubProp.setProperty("P_pub_"+KGC, P_pub.toString());
        storePropToFile(PubProp,publicFile);

    }

    public static void setup1(String pairingFile,String publicFile) {

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element P = bp.getZr().newRandomElement().getImmutable();
        Properties PubProp =new Properties();
        PubProp.setProperty("P",P.toString());
        storePropToFile(PubProp,publicFile);

    }
    public static void Registration(String pairingFile,String publicFile,String mskFile,String pkFile,String certiFile,String skFile,String KGC,String ID_i) throws NoSuchAlgorithmException {

        //获得主公钥
        Pairing bp=PairingFactory.getPairing(pairingFile);

        Properties pubProp=loadPropFromFile(publicFile);
        Properties certip=loadPropFromFile(certiFile);
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);

        //生成私钥
        //用户自己选择私钥
        Element v_i=bp.getZr().newRandomElement().getImmutable();
        Element V_i=P.powZn(v_i).getImmutable();

        //KGC生成部分私钥
        Element r_i=bp.getZr().newRandomElement().getImmutable();
        Element IC_i=V_i.add(P.powZn(r_i));
        byte[] bH_1=sha0(s.powZn(V_i).toString());
        byte[] bH_2=sha0(ID_i+IC_i+P_pub);
        Element H_1=bp.getZr().newElementFromHash(bH_1,0,bH_1.length).getImmutable();
        Element H_2=bp.getZr().newElementFromHash(bH_2,0,bH_2.length).getImmutable();
        Element Xi_i = H_1.add(r_i.add(s.mul(H_2))).getImmutable();


        byte[] bH_11=sha0(v_i.powZn(P_pub).toString());
        Element H_11=bp.getZr().newElementFromHash(bH_11,0,bH_11.length).getImmutable();
        Element d_i = Xi_i.sub(H_11).getImmutable();
        Element sk_i = v_i.add(d_i).getImmutable();
        if (sk_i.powZn(P).isEqual(H_2.add(IC_i).powZn(P_pub)))
        {

        }
        skp.setProperty("d_"+ID_i,Base64.getEncoder().encodeToString(d_i.toBytes()));
        skp.setProperty("sk_"+ID_i,Base64.getEncoder().encodeToString(sk_i.toBytes()));
        certip.setProperty("IC_"+ID_i,IC_i.toString());
        storePropToFile(pkp,pkFile);
        storePropToFile(skp,skFile);
        storePropToFile(certip,certiFile);

    }


    public static void Signcryption(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String certiFile,String authFile,String KGC,String ID_u,String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties certip=loadPropFromFile(certiFile);
        Properties authp=new Properties();
        String Pstr=pubProp.getProperty("P");
        String P_pubistr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        Element P_pub=bp.getG1().newElementFromBytes(P_pubistr.getBytes()).getImmutable();
        //获得主私钥
        Properties mskp=loadPropFromFile(mskFile);
        String s_istr=mskp.getProperty("s_"+KGC);
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();

        Properties pkp=loadPropFromFile(pkFile);
        Properties skp=loadPropFromFile(skFile);
        Element m = bp.getZr().newRandomElement().getImmutable();
        Element x = bp.getZr().newRandomElement().getImmutable();
        Element l_s = bp.getZr().newRandomElement().getImmutable();
        Element L_s = P.powZn(l_s).getImmutable();
        Element[] E_ri = new Element[n],e_ri = new Element[n],IC = new Element[n];

        for(int i = 0; i < n; i++)
        {
            String IC_istr=certip.getProperty("IC_"+ID[i]);
            IC[i] = bp.getZr().newElementFromBytes(IC_istr.getBytes()).getImmutable();
            byte[] bH_2=sha0(ID[i]+IC[i]+P_pubistr);

            Element H_2=bp.getZr().newElementFromHash(bH_2,0,bH_2.length).getImmutable();
            E_ri[i] = l_s.powZn(IC[i].add(H_2.powZn(P_pub))).getImmutable();
            byte[] bH_3=sha0(E_ri[i].toString());
            e_ri[i]=bp.getZr().newElementFromHash(bH_3,0,bH_3.length).getImmutable();
        }
        Double dsum1 = 0.0, dsum2 = 1.0;
        Element sum1 = bp.getZr().newElementFromBytes(String.valueOf(dsum1).getBytes()).getImmutable();
        Element sum2 = bp.getZr().newElementFromBytes(String.valueOf(dsum2).getBytes()).getImmutable();
        for (int i = 0; i < n; i++)
        {
            for(int j = 0; j < n&&i!=j;j++)

              sum2 = sum2.mul(x.sub(e_ri[j]).div(e_ri[i].sub(e_ri[j])));
            sum1 = sum1.add(sum2);
        }
        sum1 = sum1.mul(m);
        Double theta = Double.valueOf(sum1.toString());
        Double []A = new Double[n];
        Double x1 = Double.valueOf(x.toString()),s2 = 0.0;
        for(int i = 0; i < n; i++)
        {
            A[i] = new Random().nextDouble();
            s2+=A[i];
            authp.setProperty("A_"+i,A[i].toString());
        }
        for(int i = 0;i < n; i++)
        {
            theta = theta-A[i]*Math.pow(x1,i);
        }
        String IC_ustr=certip.getProperty("IC_"+ID_u);
        Element IC_u = bp.getZr().newElementFromBytes(IC_ustr.getBytes()).getImmutable();
        byte[] bH_4=sha0(ID_u+IC_u+L_s+s2);
        Element H_4=bp.getZr().newElementFromHash(bH_4,0,bH_4.length).getImmutable();
        String sk_ustr=skp.getProperty("sk_"+ID_u);
        Element sk_u=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(sk_ustr)).getImmutable();
        Element Sigma = l_s.add(sk_u.mul(H_4));
        authp.setProperty("L_"+ID_u,L_s.toString());
        authp.setProperty("sigma_"+ID_u,Sigma.toString());
        storePropToFile(authp,authFile);
    }
    public static void Verify(String pairingFile,String publicFile,String mskFile,String pkFile,String skFile,String certiFile,String authFile,String veriFile,String KGC,String ID_u,String[] ID,int n) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        Properties mskp=loadPropFromFile(mskFile);
        Properties certip=loadPropFromFile(certiFile);
        Properties authp=loadPropFromFile(authFile);
        Properties skp=loadPropFromFile(skFile);
        String Pstr=pubProp.getProperty("P");
        Double sum1 = 0.0;
        String P_pubstr=pubProp.getProperty("P_pub_"+KGC);
        Element P=bp.getZr().newElementFromBytes(Pstr.getBytes()).getImmutable();
        String s_istr=mskp.getProperty("s_"+KGC);
        Double []A = new Double[n];
        for (int i = 0; i < n; i++)
        {
            String a1 = authp.getProperty("A_"+i);
            A[i] = Double.valueOf(a1);
        }
        Element s=bp.getZr().newElementFromBytes(Base64.getDecoder().decode(s_istr)).getImmutable();
        Element P_pub=bp.getZr().newElementFromBytes(P_pubstr.getBytes()).getImmutable();
        String IC_ustr = certip.getProperty("IC_"+ID_u);
        Element IC_u=bp.getZr().newElementFromBytes(IC_ustr.getBytes()).getImmutable();
        byte[] bH_2 = sha0(ID_u+IC_ustr+P_pubstr);
        Element a_s = bp.getZr().newElementFromHash(bH_2,0,bH_2.length).getImmutable();
        String L_sstr=authp.getProperty("L_"+ID_u);
        Element L_s = bp.getZr().newElementFromBytes(L_sstr.getBytes()).getImmutable();
        String sigma_sstr=authp.getProperty("sigma_"+ID_u);
        Element sigma = bp.getZr().newElementFromBytes(sigma_sstr.getBytes()).getImmutable();
        byte[] bbeta = sha0(ID_u+IC_ustr+L_sstr);
        Element beta = bp.getZr().newElementFromHash(bbeta,0,bbeta.length).getImmutable();
        Element[] E_ri = new Element[n],e_ri = new Element[n];
        Element t1 = sigma.powZn(P).getImmutable();
        Element t2 = L_s.add(beta.mul(IC_u).add(a_s.mul(beta.mul(P_pub))));
        if (sum1!=1)
        {
            for (int i = 0; i < n; i++)
            {
                String sk_istr = skp.getProperty("sk_"+ID[i]);
                Element sk_i = bp.getZr().newElementFromBytes(sk_istr.getBytes()).getImmutable();
                E_ri[i] = sk_i.mul(L_s).getImmutable();
                byte[] bH_3 = sha0(E_ri[i].toString());
                e_ri[i] = bp.getZr().newElementFromHash(bH_3,0,bH_3.length).getImmutable();

            }
            for (int i = 0; i < n; i++)
            {
                sum1+=A[i]*Math.pow(Double.valueOf(e_ri[i].toString()),i);
            }

        }
        else
        {
            out.println("验证失败");
        }
    }



    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Yu/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String certificateFileName=dir+"certi.properties";
        String authenticationFileName=dir+"auth.properties";
        String verifyFileName=dir+"Veri.properties";

        int n = 200;
        String KGC="KGC";
        String ID_u="User";
        String[] ID = new String[n];
        for (int i=0;i<n;i++){
//            long sta = System.currentTimeMillis();

//            long end = System.currentTimeMillis();
//            out.println(end-sta);
            ID[i] = getRandomString(10);
        }

        setup1(pairingParametersFileName,publicKeyFileName);
        setup(pairingParametersFileName,publicParameterFileName,mskFileName,KGC);
        Registration(pairingParametersFileName, publicParameterFileName,mskFileName,publicKeyFileName,certificateFileName,secretKeyFileName,KGC,ID_u);
        for (int i = 0; i < n; i++)
            Registration(pairingParametersFileName, publicParameterFileName,mskFileName,publicKeyFileName,certificateFileName,secretKeyFileName,KGC,ID[i]);
        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();

            Signcryption(pairingParametersFileName,publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName, certificateFileName,authenticationFileName,KGC,ID_u,ID,n);
            Verify(pairingParametersFileName, publicParameterFileName, mskFileName, publicKeyFileName, secretKeyFileName, certificateFileName,authenticationFileName,verifyFileName,KGC,ID_u,ID,n);

            long end = System.currentTimeMillis();
            System.out.println(end - start);
        }





        /*long start1 = System.currentTimeMillis();

            long end1= System.currentTimeMillis();
            System.out.println(end1 - start1);


        */


    }
    public static String getRandomString(int length){

        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        Random random=new Random();

        StringBuffer sb=new StringBuffer();

        for(int i=0;i<length;i++){

            int number=random.nextInt(62);    //从62个字符中随机取其中一个

            sb.append(str.charAt(number));  //用取到的数当索引取字符加到length个数的字符串

        }

        return sb.toString();  //返回字符串

    }
}
